package mypackage;

public class AnotherClass {
    public static void main(String[] args) {
        MyClass myObject = new MyClass(20);
        int number = myObject.protectedNumber;
        System.out.println("Accessed protected number: " + number);
    }
}
