package mypackage;

public class MyClass {
    protected int protectedNumber;

    public MyClass(int protectedNumber) {
        this.protectedNumber = protectedNumber;
    }
}
