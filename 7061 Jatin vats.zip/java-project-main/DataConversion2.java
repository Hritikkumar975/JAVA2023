public class DataConversion2{
    public static void main(String[] args) {
int num = 42;

String str = Integer.toString(num);

System.out.println(str);

    }
}
