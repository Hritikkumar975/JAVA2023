// Program to find the most repeated word in a text file
// Created by Aryan , Rollno 7070
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class String29 {
    public static void main(String[] args) {
        // Specify the path to your text file
        Path filePath = Path.of("words.txt");

        try {
            // Read the content of the text file and tokenize it into words
            String content = Files.readString(filePath);
            String[] words = content.split("\\s+");

            // Count occurrences of each word using Java Streams
            Map<String, Long> wordCountMap = countWordOccurrences(words);

            // Find the most repeated word
            String mostRepeatedWord = findMostRepeatedWord(wordCountMap);

            // Display the result
            System.out.println("Most Repeated Word: " + mostRepeatedWord);
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

    private static Map<String, Long> countWordOccurrences(String[] words) throws IOException {
        return Files.lines(Path.of("words.txt"))
                .flatMap(line -> List.of(line.split("\\s+")).stream())
                .map(word -> word.replaceAll("[^a-zA-Z]", "").toLowerCase())
                .collect(Collectors.groupingBy(w -> w, Collectors.counting()));
    }

    private static String findMostRepeatedWord(Map<String, Long> wordCountMap) {
        return wordCountMap.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }
}
