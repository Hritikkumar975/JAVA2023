import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SimpleFontSetter extends JFrame {

    private JLabel label;

    public SimpleFontSetter() {
        setTitle("Font Setter");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLayout(new FlowLayout());

        label = new JLabel("Hello, Font!");
        add(label);

        JButton fontButton = new JButton("Set Font");
        fontButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setFont();
            }
        });
        add(fontButton);
    }

    private void setFont() {
        Font currentFont = label.getFont();
        Font selectedFont = JFontChooser.showDialog(this, "Choose Font", currentFont);

        if (selectedFont != null) {
            label.setFont(selectedFont);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SimpleFontSetter fontSetter = new SimpleFontSetter();
            fontSetter.setVisible(true);
        });
    }
}
